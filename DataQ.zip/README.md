# DataQ

DataQ is an MQTT client for Axis cameras that enables custom data-driven solutions when standard camera data and formats are insufficient. It processes, filters, and transforms camera analytics before MQTT publishing to optimize resource usage.
DataQ makes integration and solution development easier by publishing purpose-built data structures for each use case, reducing bandwidth and adding pre-calculated properties such as age, distance, direction, speed, and idle time.

> **DataQ** targets Axis cameras.
> **DataQ_Radar** targets Axis Radar models **D2110** and **D2210**.

***
## Key Features

**Data Processing**
- Pre-calculated properties that simplify data processing.
- Resource-efficient publishing
- Optimized data transformation
- Real-time analytics processing
- WYSIWYG. All video overlays are generated from data published on MQTT.

**Data Filters**
- Data type publish
- Class labels
- Confidence level
- Polygon Area of Interest and exclusion zones
- Min/max object width and height
- Max idle time (when objects are considered to be part of background)

**Target Users**
- System integrators
- Custom solution developers
- Data-driven application builders

## Prerequisites

**DataQ (cameras)**
- Axis camera (ARM7HF or AARCH64 architecture)
- Newer firmware generally provides better analytics data

**DataQ_Radar (radars)**
- Axis Radar D2110 or D2210

**Both**
- MQTT Broker with WebSocket support
- MQTT client for data consumption

***

### Pre-compiled download

If you are only after a pre-compiled version, [Download Latest ZIP](https://www.dropbox.com/scl/fi/03gzooytc2cakmrl7kh5r/DataQ.zip?rlkey=3zx1mhin5obw6aaqz0sv5a142&dl=1)<br>
The ZIP file contains:
- **DataQ** — pre-compiled for armv7hf and aarch64 (Axis cameras)

DataQ_Radar builds are distributed separately.

It is a good idea to regularly download the latest version as new features and bug fixes are published.<br>

***

If you find this ACAP valuable, please consider [buying me a coffee](https://buymeacoffee.com/fredjuhlinl).  

***

## Data Types

### Events
Event-based triggers for actions, offering streamlined MQTT message publishing compared to standard Axis device capabilities.

### Object Analytics

**Detection Data**
- Real-time object detection
- Bounding box information
- Classification data
- High data throughput

The Detections page controls detection publishing, detection settings, label filtering, and scene filters. Disabling **Publish Detections** stops the detections MQTT stream and hides the live video/AOI/exclusion-zone editor, while **Detection Settings** and **Label Filter** remain available for configuration.

**Detection Scene Filters**
- **Area of Interest** — one polygon where detections are accepted. Leave it empty to use the full frame; use **Clear** to remove the current AOI.
- **Exclusion Zones** — one or more polygons where detections are ignored. Each zone can be named, enabled/disabled, or deleted.
- **Size Filter** — min/max object width and height are configured on the **Advanced** page.

**Tracker Data**
- Movement-based updates (and 2-second intervals)
- Direction, speed, and distance metrics
- Optimized bandwidth usage

**Path Data**
- Ideal for post-processing applications
  - Flow heatmaps
  - Dwell analysis
  - Forensic searching
  - Object counting
- Minimal bandwidth consumption and post-processing needs

**Occupancy Data**
- Tracks the number of detected objects in the scene, per class label
  - Queue management
  - Loitering detection
  - Space utilisation

  Occupancy supports up to 8 configurable polygon areas. Each area publishes its own counter independently.

  Two output modes are available:
  - **On change** — publishes immediately whenever a counter changes. A configurable hold-down delay prevents rapid fluctuations when counts decrease.
  - **Periodic** — accumulates detections over a selected interval (1, 2, 5, 10 or 15 minutes) and publishes the average count per label as a float with one decimal of precision. Useful for trend monitoring and dashboards where average load matters more than instantaneous changes.

**Geospace Data**  
  
Geospace transforms the object detections x/y space in video to longitude and latitude. The technology used is homography.  
In order to get a good result, it is recommended that the calibration markers cover the area where objects move while maximizing the 4-corner area. It is also recommended to enable the camera's Barrel distortion correction (Menu | Installation | Image correction).  
You may add more than 4 markers if needed, but it may also make things worse.  

Geospace data uses Trackers for the transformations. Trackers do not need to be published but you may need to adjust both "Detections" and "Trackers".  
Recommended settings:  
* Enable the cameras Barrel distortion correction.
* Set Detections "Max idle" to 5 or 10 seconds to prevent sending location for stationary objects.
* Set Detection COG (Center-of-Gravity) to bottom-center.
* Disable all labels under Detections you are not interested in.
* Set Tracker "Minimum distance" to 5% or more to prevent stationary objects from being falsely detected as moving.

1. Click "Edit Markers".  
  - Use the mouse to move the map to the area the camera is located. Click "Save map"
  - Add 4 markers by clicking the left mouse in the video. A corresponding marker will be displayed in the map. 
	Move the markers to distinct positions (e.g. corner of a building)
	Marker is removed by right-clicking on the marker in the video view.  
  - Click "Save and calibrate"
2. Click "Verify"
  - Use the mouse and left-click in the video view. A marker will be shown in the map. See how well they correlate. You may need to go back to step 1 and adjust calibration.  
3. Click "Monitor"
  - Detected moving Objects will be displayed in both video and map view.

Check out the Node-RED example worldmap-flow.json under examples. Import the worldmap node and the worldmap-flow.json to your Node-RED. Configure the MQTT client.  

### Monitoring Data

**Status Data**
MQTT Heartbeat published every 15 minutes
- Network load monitoring
- CPU usage tracking
- Uptime statistics

## Integration Specifications

### Coordinate System
- Relative coordinates [0...1000][0...1000] (Aspect ratio independent)
- Origin: Top-left corner

### Data Properties

| Property   | Type / Format | Description & Usage |
|------------|---------------|---------------------|
| **id**     | `string` | Unique tracking ID assigned per object during its lifetime in the scene. Used as a primary key when correlating updates. |
| **type**   | `string` or `int` | Internal object type code (implementation detail). Typically maps to a `class` but may be model‑specific. Usually not needed unless doing low‑level integrations. |
| **class**  | `string` | Semantic classification label (e.g., `"Person"`, `"Car"`, `"Bike"`, `"Bag"`). Primary field to identify object categories for business logic (counts, alerts, analytics). |
| **active** | `boolean` | Indicates whether the object is currently visible/trackable. Useful for knowing when objects have exited the scene. |
| **x, y, w, h** | `int` (pixels) | Bounding box rectangle: top‑left `(x,y)` position and box size `(w,h)`. Used to draw boxes in UIs or compute relative object size. |
| **cx, cy** | `int` (pixels, normalized 0–1000 optional) | Object’s positional anchor point (center or bottom‑center). Used for tracking paths, heat maps, and trajectory analyses. |
| **dx, dy** | `int` (pixels or normalized units) | Net displacement `(current − initial)` in X and Y directions. Indicates travel direction: `dx > 0 = right`, `dy > 0 = down`. Useful for direction/flow detection. |
| **birth**  | `int` (epoch seconds/milliseconds) | Timestamp when the object first appeared. Used for age/duration calculations. |
| **bx, by** | `int` (pixels) | Position coordinates where the object first entered the scene. Can be used for entry‑point analysis. |
| **age**    | `float` (seconds) | Time since first detection. Key metric for dwell time, stay duration, and filtering short vs long presence. |
| **idle**   | `float` (seconds) | How long the object has been stationary (resets on movement). Supports use cases like idle vehicle/person detection, abandoned luggage, or loitering alerts. |
| **maxIdle**| `float` (seconds) | The maximum idle time the object had while in scene |
| **speed**  | `float`| The speed is distance/age and represents %movement of the view / seconds |
| **maxSpeed**  | `float`| The highest speed detected of the object |
| **confidence** | `int` (0–100) | Detection confidence score. Use thresholding to discard low-confidence objects and minimize false positives. |
| **timestamp**  | `int` (epoch seconds/milliseconds) | Last frame time where the object was seen. Useful for synchronization and gap detection. |
| **color, color2** | `string` (label) | Primary and secondary detected color labels (e.g., `"red"`, `"blue"`). Helps with descriptive analytics (red car, blue shirt). May be `null` if unavailable. |
| **anomaly**   | `string` (Reason) | Only included if the anomaly service detected anomaly in Tracker or paths |
| **path**   | `array` of objects | Sequence of position and dwell samples. Each entry contains `{x, y, d, lat?, lon?}`. Use to reconstruct trajectories, heatmaps, or identify where objects dwell most. |
| **lat, lon** | `float` (GPS coords) | Latitude/Longitude if a homography matrix is available. Enables geo‑position mapping in real-world coordinates instead of pixels. |
| **name**   | `string` | Camera name or location identifier (e.g., `"LobbyCam1"`). Useful for human-readable references. |
| **serial / device** | `string` | Unique hardware device identifier. Supports multi-camera/log correlation. |
| **localTime** | `string` (timestamp, local timezone) | Human‑readable local time when the event occurred. Useful for logs, reports, and non‑technical stakeholders. |

***

## Advanced Settings

The Advanced page provides tools for optimizing DataQ behavior in challenging scenes where the default analytics may produce fragmented or inaccurate data. Access it from the sidebar under **Advanced**.

### Perspective Guard

Defines a cut-off boundary on the camera view. When a tracked object's center crosses from inside to outside this boundary, the object is finalized and any subsequent reuse of the same tracker ID by the analytics engine is treated as a new, separate object.

**When to use:**  
In scenes with strong perspective (e.g., a street receding from the camera) where an outgoing object disappears at a distance and an incoming object is assigned the same tracker ID — creating a false path that reverses direction.

**Tips:**
- Draw the boundary generously so legitimate objects near the edge are not cut off prematurely.
- Objects that first appear *outside* the boundary are still tracked normally — the guard only fires on inside-to-outside transitions.
- Works independently of the Area-of-Interest filter on the Detections page.

### Object Stitching

Automatically merges path segments from the same physical object that temporarily disappears and reappears (e.g., a person walking behind a pillar). Without stitching, each disappearance produces a separate path; with stitching, they are joined into one continuous path.

**Settings:**
- **Max Duration (s)** — Maximum gap between the end of one path and the start of the next for them to be considered the same object (1–10 seconds).
- **Angle Threshold (°)** — Maximum allowed difference between the direction of the outgoing and incoming paths (0–90°). Set to 0 to ignore direction entirely.
- **Allow Class Switch** — When enabled, objects can be matched even if their classification label changes (e.g., "vehicle" → "car"). The label with the highest confidence is kept.
- **Stitch Area** — An area in the video where objects are expected to disappear and reappear. Only paths that end or start within this area are candidates for stitching.

**Tips:**
- Too large a duration or angle threshold may incorrectly merge different objects.
- Stitched paths are shown in green on the video overlay; normal paths in yellow.

### Tracker Predictions

When enabled, the analytics engine includes predicted positions for objects that are temporarily not visible. This helps maintain tracking continuity during brief occlusions.

**When to use:**  
In scenes where objects frequently pass behind obstacles (poles, pillars, signs) and you want smoother, more continuous tracking.

**Things to consider:**
- Predictions are estimates and may be inaccurate for objects that change speed or direction while occluded.
- **Changing this setting requires an ACAP restart** to take effect.
- May slightly increase CPU usage on the camera.

### Size Filter

Filters objects by minimum and maximum width/height in the normalized 0-1000 scene coordinate space. Use this to suppress very small false detections or very large objects that should not be counted or published for your use case.

**Settings:**
- **Min width / Min height** — Objects smaller than these limits are ignored.
- **Max width / Max height** — Objects larger than these limits are ignored.
- Size filter values are saved from the **Advanced** page and apply to detection processing, regardless of whether detection publishing is currently enabled.

***

## Anomaly Detection Settings & Usage

The anomaly detection service helps highlight abnormal object behaviors in your scene, assisting users to focus attention where needed most. Objects marked with `"anomaly": "<reason>"` are flagged in MQTT data, and a stateful event is triggered as long as the anomaly persists.

### What is an Anomaly?

An anomaly indicates that an object’s movement or behavior deviates from what is defined as normal in your configuration. This is not about detecting intrusions, but about identifying outliers or unusual system activity that may merit review. Use anomaly detection to monitor for unexpected appearances, exits, motion patterns, loitering, or excessive speed—all customizable per your application needs.

### Configuration Overview

- **Object Type Selection:**  
  Choose to monitor anomalies for Humans, Vehicles, or both. Each type has separate statistics and behavior profiles for optimized detection.

- **Entry/Exit Areas:**  
  Specify one or more areas in the scene as normal entry/exit points. When an object appears or disappears outside these regions, it is flagged as an anomaly. Avoid using this feature if entries or exits can occur anywhere; restrict its use to controlled or predictable zones for reliable results.

- **Max Direction Changes:**  
  Set the maximum number of distinct direction changes an object can make before it is considered abnormal. This is useful for flagging zig-zag motion or non-standard traversal paths.

- **Horizontal/Vertical Direction:**  
  Define whether normal movement should be left/right (horizontal) or up/down (vertical). Default is “Any,” which means all directions are acceptable and won’t trigger anomalies on direction alone.

- **Max Idle Time:**  
  Establish how long an object may pause while traversing the view before being considered anomalously idle (e.g., loitering, stopping unexpectedly).

- **Max Age:**  
  Set how long an object is allowed to remain in the scene before being considered abnormal (e.g., extended dwell time).

- **Max Speed:**  
  Define what range of speeds are considered normal. Exceeding this speed will be flagged as an anomaly.

- **Disable Checks:**
  Setting any parameter to zero disables checking for that metric.

### System integration

On MQTT, Trackers and Paths will have an additional property "anomaly" with a "Reason".  
For VMS (Video Management Systems), a stateful event "anomaly" will be fired and stay high as long as there is a detected anomaly.

### Practical Guidance

- **Statistics Area:**  
  The settings screen displays live statistics for the last 100 Humans and Vehicles detected, including lowest, average, highest, and 95% percentile values per metric. Let the system run for hours or days to collect baseline data and configure thresholds that fit your real-world conditions.

- **Iterative Tuning:**  
  Start with broad settings, observe flagged anomalies, and refine thresholds based on what you see in the statistics area. This prevents over-alerting and false positives, improving utility over time.

- **Entry/Exit Configuration:**  
  Only configure entry/exit areas if regular entry/exit points exist—otherwise unpredictable entrances/exits may yield excessive anomalies.

- **Event Triggering:**  
  Each anomaly triggers a stateful event while ongoing, allowing MQTT consumers to react in real-time (alert operators, record video, etc.).

### Best Practices

- Define "normal" based on your business goals and operational context (e.g., security, process monitoring, safety).
- Maintain clear records of configuration changes and review flagged events periodically to improve detection quality.
- Periodically review the anomaly statistics to ensure thresholds are set appropriately and adapt them as usage patterns evolve.
- Use the system’s data-driven insights—don’t rely solely on pre-set defaults.

***

## MQTT Configuration

### Broker Setup Options
- [Mosquitto](https://mosquitto.org/)  
  Add the following to your mosquitto.conf
  ```
  listener 1884
  protocol websockets
  ```
- [Node-RED AEDES](https://flows.nodered.org/node/node-red-contrib-aedes)  
  Bind WS port 1884 in the AEDES settings

### Requirements
- WebSocket support for data visualization in the user interface


> **Note**: This ACAP deprecates and replaces SIMQTT, ObjectTracker, ObjectPath and Occupancy  
> **Note**: Use DataQ when standard Axis device services and data formats do not meet your requirements.

***

## History

### 3.3.0 Jun 23, 2026

**Security and Stability Patches**
- Updated the Detections page with polygon AOI and exclusion-zone filtering while preserving compatibility with the old rectangular AOI settings.
- Added a Clear control for Area of Interest, moved Size Filter controls to the Advanced page, and kept Detection Settings / Label Filter editable when detection publishing is disabled.
- Added stale tracker cleanup from [InSupportMH](https://github.com/InSupportMH): when VOD silently drops a track without an `active=false` frame, DataQ now publishes one terminal tracker update and removes the stale cache entry instead of republishing frozen coordinates indefinitely.
- Hardened MQTT and certificate handling: MQTT passwords are redacted from public settings responses, JSON endpoints reject unsupported methods/content types more consistently, and certificate/private-key material is written with stricter file permissions.
- Increased HTTP POST capacity for larger settings payloads and tightened FastCGI socket permissions/logging.
- Reduced DOM injection risk in several UI pages by replacing dynamic HTML string insertion with DOM/text APIs for table rows, messages, and toast content.

### 3.2.0 Apr 10, 2026

**Multi-area Occupancy** *(occupancy_multi_area branch)*
- Occupancy zones are now defined as free-form polygons drawn directly on the live video feed — up to 8 independent areas per camera. Each area gets its own MQTT topic: `occupancy/<serial>/<area_name>`, with the full-scene fallback topic (`occupancy/<serial>`) still published when no areas are configured
- Per-area counter payload includes only labels that have been counted at least once (zero-count classes are suppressed until they appear; once seen, they are always included even at zero)
- Two publish modes available, selectable per deployment:
  - **On change** — count increases publish immediately; decreases are held for a configurable `holdTime` (default 3 s) and cancelled if the count recovers before the timer fires, preventing rapid fluctuations
  - **Periodic** — accumulates detections over a selected interval (1, 2, 5, 10, or 15 minutes) and publishes the average count per label as a float with one decimal of precision; useful for trend monitoring and dashboards

**Tracker Significant-Movement Filter** *(tracker-filter branch)*
- Added `significantMovement` setting to the scene configuration to suppress tracker MQTT updates from objects that have not moved a meaningful distance.  
- The scene is split into an upper and a lower region by a configurable horizontal dividing line (y-coordinate in 0–1000 space, default 400)
- Objects in the **upper** region (further from camera, smaller apparent size) must move at least `upperArea`% of their bounding-box size before a tracker update is published (default 30%)
- Objects in the **lower** region (closer to camera, larger apparent size) require `lowerArea`% movement (default 70%)

### 3.1.5 Mar 16, 2026
- **Geospace calibration persistence** — Fixed duplicate `markers` and `matrix` keys in settings.json template that caused calibration data to be overwritten with empty arrays after saving
- **Geospace marker initialization** — Corrected initialization sequence to load saved markers after video element is created, ensuring markers display properly when switching to Calibrate mode
- **Path geolocation coordinates** — Fixed condition check that prevented `lat` and `lon` properties from being added to path points when coordinates were `0,0` or other valid locations; now checks the GeoSpace transformation success instead

### 3.1.3 Mar 5, 2026
- **Geospace calibration** — Calibration markers now correctly reappear when switching to Calibrate mode after a page refresh (marker positions were computed before the video stream had rendered, causing all markers to land at 0,0)
- **Ceiling (Fisheye) COG** — New COG mode for overhead fisheye cameras; shifts the anchor point toward the image center proportionally to the object's distance from center and its size, giving a more accurate ground-contact point for radially distorted views
- **Stitch overhaul** — Rewrote path-stitching logic to fix the most common failure modes:
  - Hold timeout increased to `duration × 24` (minimum 60 s) so pre-occlusion paths are not discarded before the post-occlusion tracker completes its journey
  - Bidirectional matching: post-occlusion paths that finalise *before* the pre-occlusion path are now held and matched in reversed order, eliminating the most common race condition
  - Best-match scoring (angular penalty + temporal penalty) replaces first-match — prevents incorrect merges when multiple objects of the same class cross the stitch area in quick succession
  - Angle estimation uses circular mean of up to 5 consecutive vectors instead of a single noisy pair
- **Documentation** — `MQTT_topics.md`: removed `"stitched": false` from the path example (property is only present when `true`), updated table description accordingly, removed `path[].t` field (stripped before publishing)

### 3.1.1 Mar 2, 2026
- Fixed label pipeline: `VOD_Label_List()` returns objects `{id, name, enabled}` rather than strings — now correctly extracts the `id` field and maps it through `NiceName()` before storing
- Added `ObjectDetection_Labels()` / `RadarDetection_Labels()` functions that read mapped label names from the status group, replacing direct VOD access in the MQTT connect message
- Labels are now stored in the status object at startup and reachable via the `/status` HTTP endpoint
- Fixed `detections.html`: Settings and Label filter cards are now always visible (were hidden inside the Publish Detections toggle area)
- Added `renderLabelSelector()` with retry logic — polls `/status` every 3 s (up to 10 attempts) until labels are available
- Fixed confidence dropdown option values (85, 90, 95 were all submitting 97)

### 3.1.0 Mar 1, 2026
- New MQTT topic `image/{serial}`: publishes a JPEG snapshot (640×360 for 16:9 cameras) encoded as Base64
  - Published immediately when enabled and then daily at 12:00 local time
- `connect/{serial}` announcement now includes a `labels` array listing all detectable object classes with `id`, `name`, and `enabled` fields
- Added **Image** toggle to the MQTT streams table in the UI
- Renamed `path-structure.md` to `MQTT_topics.md` with full topic and payload documentation
- Added `publish.image` setting (default: disabled)
- `ACAP_DEVICE_Set_Location()` now accepts a third `heading` parameter (degrees)

### 3.0.1 Feb 25, 2026
- Fixed OpenStreetMap not displaying on the Geospace page
- Fixed critical bug where homography matrix was not loaded at startup, causing all geospace transforms to fail until re-calibration
- Switched matrix library from single (float) to double precision for accurate GPS coordinate transformations
- Improved Geospace UI
  - Context-sensitive help text for each mode (Monitor, Calibrate, Validate)
  - Live marker count with calibration readiness feedback
  - Numbered tooltips on map markers matching video marker labels
  - Clear All button for resetting markers
  - Crosshair cursor and click indicator in Calibrate and Validate modes
  - Map auto-pans to validation result
  - Pre-save validation requiring minimum 4 markers
- Added re-projection error validation when calibrating homography
- Added input range validation for geospace HTTP endpoint
- Added confidence and distance fields to geospace MQTT messages
- Removed dead code and minor fixes

### 3.0.0 Feb 21, 2026
- New Advanced settings page for scene optimization
  - **Perspective Guard** — Cut-off boundary to prevent false path reversals in perspective scenes
  - **Object Stitching** — Automatic path merging for objects that temporarily disappear behind obstacles
  - **Tracker Predictions** — Enable predicted positions during brief occlusions for smoother tracking
- Enhanced path stitching functionality
  - Conditional angle threshold checking (setting to 0 disables direction matching)
  - Improved path holding logic for more reliable stitching behavior
  - Allow class switching — stitched paths can adopt the class from higher confidence segments
- UI improvements
  - Extended angle threshold range from 20-60° to 0-90° for greater flexibility
  - Updated help text to clarify that 0 = ignore direction
- Stability fixes
- Bug fixes

### 2.1.9 Jan 1, 2026
- Fixed critical deadlock vulnerability
- Fixed path dwell calculation
- Improved thread safety
- Added properties in connect and status publish

### 2.1.8 Nov 17
- Fixed time issues in Path.  Age and duration in path array is now correct.

### 2.1.7 Oct 3
- Settings are now correctly stored in Detections.

### 2.1.6 Sep 29
- Fixed client certificate authentication for MQTT
- Anomaly still in Beta
- Occupancy now working as expected
- Fixed a flaw that prevented users from updating the Detections areas

### 2.1.1 Sep 24

- Marked Anomaly as "Beta" as testing is ongoing.  
  Please send comments, questions, error reports and suggestions for improvements.  

### 2.1.0 Sep 23
- Added anomaly detection. Trackers and Path are marked with property "anomaly": "The reason".  
  Vehicles and humans are treated individually
	* Normal Entry areas (first detected position)
    * Normal Exit Areas (last detected position)
    * Max numbers of direction changes (zig-zag movement)
    * Max idle time
    * Max age
    * Vertical movement (Wrong way)
    * Horizontal movement (Wrong way)
    * Max Speed
- Trackers are now published immediately when detected. Previous behavior required new object to move.
- Box area selection has been updated.

### 2.0.4 Sep 12
- Fixed Occupancy to have the value of the number of each detected labels.

### 2.0.3 Sep 7
- Path timestamp is now correct

### 2.0.2 Sep 2
- Fixed WEB GUI screw up, displaying the wrong index page.
  
### 2.0.0 July 14

- Major code refactoring for enhanced stability and future compatibility, especially across varying camera firmware versions.
  - Upgraded to SDK 12.2 (from SDK 3.5) for improved long-term support.
  - Switched MQTT library from synchronous to asynchronous, providing more robust reconnect and connection management.
  - Improved object detection pipeline to better accommodate firmware differences and prepare for upcoming changes.
- Introduced new `"idle"` property, which reports how long (in seconds) an object has remained stationary. This value resets when movement is detected.
- Occupancy analytics now allow you to count stationary objects, moving objects, or both, giving more flexibility and precision in reporting.

### 1.5.0	June 14, 2025
- Optimized the detections data structure by reducing its size (properties removed)
- Updated MQTT to use the MQTTAsync client.

### 1.4.6	May 14, 2025
- Fixed a bug that caused respawn of the ACAP

### 1.4.5	May 6, 2025
- Fixed MQTT reconnect issue

### 1.4.4	April 14, 2025
- Perodically force re-connection if needed as lostConnection may be missed
- Fixed LWT topic

### 1.4.3	April 14, 2025
- Reset the client on re-connect
- Fixed LWT topic

### 1.4.2	March 23, 2025
- Improved MQTT Reconnection stability

### 1.4.1	March 13, 2025
- Added Geospace data (Check documentation above).
- Added web page MQTT connection message box to know if the web page is connected or not.
- Bug fixes

### 1.3.0	March 3, 2025
- Replaced "Max age" with "Max idle".  
  When Max idle time is set, detections are not published when after not moving X seconds.  
  When the object starts moving, the same object ID will be used when publishing. Age, birth and distance will be preserved.    
  Occupancy is impacted and will not count idle objects.  
  Path will be published when object is idle.  
- Restructuring GUI

### 1.2.10	March 3, 2025
- Fixed MQTT TLS flaws introduced in refactoring (1.2.9)

### 1.2.9	March 2, 2025
- Refactoring MQTT client
  * Announcement retained message
  * Disconnect retained message
- User interface updates

### 1.2.8	February 22, 2025
- Created a new Menu "Scene" to be used to monitor and configure scene behavior
- Added support for enabling low confident trackers.
- Added temporarily enabling publishing for objects needed for a specific page if the publishing is disabled. The publishing will be disabled again when leaving the page.
- Fixed MQTT stability (recurring disconnects)
- Added WSS port and a way to enforce the client to use WSS even for pages accessed with HTTP. WSS will always be used when a page is accessed over HTTP.

### 1.2.7	February 12, 2025
- Fixed logic and reference flaws.
  Pull Request from InSupport

### 1.2.6	February 9, 2025
- Fixed support for data visualization when accessing camera over HTTPS with Secure WebSockets in client

### 1.2.5	February 3, 2025
- Adjustments on MQTT payload for path
- Allow multiple web browsers (and tabs) visualize MQTT messages

### 1.2.0	February 3, 2025
- Fixed "hanging-objects" due to changes in Axis OS12
- Fixed a memory leak (event processing)
- Fixed faulty center-of-gravity when camera is rotated
- Detections filter will only impact Occupancy but no longer Trackers & Paths
- Tracker filter impacts Path

### 1.1.1	January 23, 2025
- Corrected Object Detection post-processing 

### 1.1.0	January 18, 2025
- Objects are now only tracked within Area-Of-Interest
- Added Scene Max Age (Detections) that defines how old an object needs to be before being ignored. Typically used for Occupancy.
- Added Occupancy

### 1.0.2	January 14, 2025
- Initial commit
